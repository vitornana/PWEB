let express = require("express");

let app = express(); // executando o express

app.set("view engine", "ejs"); // setando o ejs como view engine

app.set("views", "./app/views"); // setando o diretório das views para ./app/views
//diretorio onde os arquivos estão localizados
module.exports = app; // exportando o app para ser utilizado em outros arquivos
